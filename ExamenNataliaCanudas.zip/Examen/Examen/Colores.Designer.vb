﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Colores
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TrackBar1 = New System.Windows.Forms.TrackBar()
        Me.lblTexto = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Panel34 = New System.Windows.Forms.Panel()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Panel35 = New System.Windows.Forms.Panel()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Panel36 = New System.Windows.Forms.Panel()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btnGenerar = New System.Windows.Forms.Button()
        Me.rbForeground = New System.Windows.Forms.RadioButton()
        Me.rbBackground = New System.Windows.Forms.RadioButton()
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TrackBar1
        '
        Me.TrackBar1.Location = New System.Drawing.Point(29, 63)
        Me.TrackBar1.Maximum = 50
        Me.TrackBar1.Minimum = 8
        Me.TrackBar1.Name = "TrackBar1"
        Me.TrackBar1.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.TrackBar1.Size = New System.Drawing.Size(45, 321)
        Me.TrackBar1.TabIndex = 0
        Me.TrackBar1.Value = 8
        '
        'lblTexto
        '
        Me.lblTexto.AutoSize = True
        Me.lblTexto.Location = New System.Drawing.Point(120, 145)
        Me.lblTexto.Name = "lblTexto"
        Me.lblTexto.Size = New System.Drawing.Size(29, 13)
        Me.lblTexto.TabIndex = 1
        Me.lblTexto.Text = "Hola"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(78, 387)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(189, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Panel31)
        Me.GroupBox1.Controls.Add(Me.Panel25)
        Me.GroupBox1.Controls.Add(Me.Panel32)
        Me.GroupBox1.Controls.Add(Me.Panel19)
        Me.GroupBox1.Controls.Add(Me.Panel33)
        Me.GroupBox1.Controls.Add(Me.Panel26)
        Me.GroupBox1.Controls.Add(Me.Panel34)
        Me.GroupBox1.Controls.Add(Me.Panel13)
        Me.GroupBox1.Controls.Add(Me.Panel35)
        Me.GroupBox1.Controls.Add(Me.Panel27)
        Me.GroupBox1.Controls.Add(Me.Panel36)
        Me.GroupBox1.Controls.Add(Me.Panel20)
        Me.GroupBox1.Controls.Add(Me.Panel28)
        Me.GroupBox1.Controls.Add(Me.Panel7)
        Me.GroupBox1.Controls.Add(Me.Panel29)
        Me.GroupBox1.Controls.Add(Me.Panel21)
        Me.GroupBox1.Controls.Add(Me.Panel30)
        Me.GroupBox1.Controls.Add(Me.Panel14)
        Me.GroupBox1.Controls.Add(Me.Panel22)
        Me.GroupBox1.Controls.Add(Me.Panel3)
        Me.GroupBox1.Controls.Add(Me.Panel23)
        Me.GroupBox1.Controls.Add(Me.Panel15)
        Me.GroupBox1.Controls.Add(Me.Panel24)
        Me.GroupBox1.Controls.Add(Me.Panel8)
        Me.GroupBox1.Controls.Add(Me.Panel16)
        Me.GroupBox1.Controls.Add(Me.Panel4)
        Me.GroupBox1.Controls.Add(Me.Panel17)
        Me.GroupBox1.Controls.Add(Me.Panel9)
        Me.GroupBox1.Controls.Add(Me.Panel18)
        Me.GroupBox1.Controls.Add(Me.Panel5)
        Me.GroupBox1.Controls.Add(Me.Panel10)
        Me.GroupBox1.Controls.Add(Me.Panel6)
        Me.GroupBox1.Controls.Add(Me.Panel11)
        Me.GroupBox1.Controls.Add(Me.Panel2)
        Me.GroupBox1.Controls.Add(Me.Panel12)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Location = New System.Drawing.Point(300, 63)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(479, 389)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Colores aleatorios"
        '
        'Panel31
        '
        Me.Panel31.Location = New System.Drawing.Point(162, 321)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(73, 54)
        Me.Panel31.TabIndex = 5
        '
        'Panel25
        '
        Me.Panel25.Location = New System.Drawing.Point(162, 262)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(73, 54)
        Me.Panel25.TabIndex = 5
        '
        'Panel32
        '
        Me.Panel32.Location = New System.Drawing.Point(242, 321)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(73, 54)
        Me.Panel32.TabIndex = 6
        '
        'Panel19
        '
        Me.Panel19.Location = New System.Drawing.Point(162, 202)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(73, 54)
        Me.Panel19.TabIndex = 5
        '
        'Panel33
        '
        Me.Panel33.Location = New System.Drawing.Point(321, 321)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(73, 54)
        Me.Panel33.TabIndex = 7
        '
        'Panel26
        '
        Me.Panel26.Location = New System.Drawing.Point(242, 262)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(73, 54)
        Me.Panel26.TabIndex = 6
        '
        'Panel34
        '
        Me.Panel34.Location = New System.Drawing.Point(400, 321)
        Me.Panel34.Name = "Panel34"
        Me.Panel34.Size = New System.Drawing.Size(73, 54)
        Me.Panel34.TabIndex = 8
        '
        'Panel13
        '
        Me.Panel13.Location = New System.Drawing.Point(162, 142)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(73, 54)
        Me.Panel13.TabIndex = 5
        '
        'Panel35
        '
        Me.Panel35.Location = New System.Drawing.Point(83, 321)
        Me.Panel35.Name = "Panel35"
        Me.Panel35.Size = New System.Drawing.Size(73, 54)
        Me.Panel35.TabIndex = 4
        '
        'Panel27
        '
        Me.Panel27.Location = New System.Drawing.Point(321, 262)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(73, 54)
        Me.Panel27.TabIndex = 7
        '
        'Panel36
        '
        Me.Panel36.Location = New System.Drawing.Point(6, 321)
        Me.Panel36.Name = "Panel36"
        Me.Panel36.Size = New System.Drawing.Size(71, 54)
        Me.Panel36.TabIndex = 3
        '
        'Panel20
        '
        Me.Panel20.Location = New System.Drawing.Point(242, 202)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(73, 54)
        Me.Panel20.TabIndex = 6
        '
        'Panel28
        '
        Me.Panel28.Location = New System.Drawing.Point(400, 262)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(73, 54)
        Me.Panel28.TabIndex = 8
        '
        'Panel7
        '
        Me.Panel7.Location = New System.Drawing.Point(162, 82)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(73, 54)
        Me.Panel7.TabIndex = 5
        '
        'Panel29
        '
        Me.Panel29.Location = New System.Drawing.Point(83, 262)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(73, 54)
        Me.Panel29.TabIndex = 4
        '
        'Panel21
        '
        Me.Panel21.Location = New System.Drawing.Point(321, 202)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(73, 54)
        Me.Panel21.TabIndex = 7
        '
        'Panel30
        '
        Me.Panel30.Location = New System.Drawing.Point(6, 262)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(71, 54)
        Me.Panel30.TabIndex = 3
        '
        'Panel14
        '
        Me.Panel14.Location = New System.Drawing.Point(242, 142)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(73, 54)
        Me.Panel14.TabIndex = 6
        '
        'Panel22
        '
        Me.Panel22.Location = New System.Drawing.Point(400, 202)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(73, 54)
        Me.Panel22.TabIndex = 8
        '
        'Panel3
        '
        Me.Panel3.Location = New System.Drawing.Point(162, 19)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(73, 54)
        Me.Panel3.TabIndex = 2
        '
        'Panel23
        '
        Me.Panel23.Location = New System.Drawing.Point(83, 202)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(73, 54)
        Me.Panel23.TabIndex = 4
        '
        'Panel15
        '
        Me.Panel15.Location = New System.Drawing.Point(321, 142)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(73, 54)
        Me.Panel15.TabIndex = 7
        '
        'Panel24
        '
        Me.Panel24.Location = New System.Drawing.Point(6, 202)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(71, 54)
        Me.Panel24.TabIndex = 3
        '
        'Panel8
        '
        Me.Panel8.Location = New System.Drawing.Point(242, 82)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(73, 54)
        Me.Panel8.TabIndex = 6
        '
        'Panel16
        '
        Me.Panel16.Location = New System.Drawing.Point(400, 142)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(73, 54)
        Me.Panel16.TabIndex = 8
        '
        'Panel4
        '
        Me.Panel4.Location = New System.Drawing.Point(242, 19)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(73, 54)
        Me.Panel4.TabIndex = 2
        '
        'Panel17
        '
        Me.Panel17.Location = New System.Drawing.Point(83, 142)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(73, 54)
        Me.Panel17.TabIndex = 4
        '
        'Panel9
        '
        Me.Panel9.Location = New System.Drawing.Point(321, 82)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(73, 54)
        Me.Panel9.TabIndex = 7
        '
        'Panel18
        '
        Me.Panel18.Location = New System.Drawing.Point(6, 142)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(71, 54)
        Me.Panel18.TabIndex = 3
        '
        'Panel5
        '
        Me.Panel5.Location = New System.Drawing.Point(321, 19)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(73, 54)
        Me.Panel5.TabIndex = 2
        '
        'Panel10
        '
        Me.Panel10.Location = New System.Drawing.Point(400, 82)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(73, 54)
        Me.Panel10.TabIndex = 8
        '
        'Panel6
        '
        Me.Panel6.Location = New System.Drawing.Point(400, 19)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(73, 54)
        Me.Panel6.TabIndex = 2
        '
        'Panel11
        '
        Me.Panel11.Location = New System.Drawing.Point(83, 82)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(73, 54)
        Me.Panel11.TabIndex = 4
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(83, 19)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(73, 54)
        Me.Panel2.TabIndex = 1
        '
        'Panel12
        '
        Me.Panel12.Location = New System.Drawing.Point(6, 82)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(71, 54)
        Me.Panel12.TabIndex = 3
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(6, 19)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(71, 54)
        Me.Panel1.TabIndex = 0
        '
        'btnGenerar
        '
        Me.btnGenerar.Location = New System.Drawing.Point(300, 25)
        Me.btnGenerar.Name = "btnGenerar"
        Me.btnGenerar.Size = New System.Drawing.Size(143, 23)
        Me.btnGenerar.TabIndex = 4
        Me.btnGenerar.Text = "Generar colores aleatoros"
        Me.btnGenerar.UseVisualStyleBackColor = True
        '
        'rbForeground
        '
        Me.rbForeground.AutoSize = True
        Me.rbForeground.Location = New System.Drawing.Point(505, 13)
        Me.rbForeground.Name = "rbForeground"
        Me.rbForeground.Size = New System.Drawing.Size(79, 17)
        Me.rbForeground.TabIndex = 5
        Me.rbForeground.TabStop = True
        Me.rbForeground.Text = "Foreground"
        Me.rbForeground.UseVisualStyleBackColor = True
        '
        'rbBackground
        '
        Me.rbBackground.AutoSize = True
        Me.rbBackground.Location = New System.Drawing.Point(505, 36)
        Me.rbBackground.Name = "rbBackground"
        Me.rbBackground.Size = New System.Drawing.Size(83, 17)
        Me.rbBackground.TabIndex = 6
        Me.rbBackground.TabStop = True
        Me.rbBackground.Text = "Background"
        Me.rbBackground.UseVisualStyleBackColor = True
        '
        'Colores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.rbBackground)
        Me.Controls.Add(Me.rbForeground)
        Me.Controls.Add(Me.btnGenerar)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.lblTexto)
        Me.Controls.Add(Me.TrackBar1)
        Me.Name = "Colores"
        Me.Text = "Colores"
        CType(Me.TrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TrackBar1 As TrackBar
    Friend WithEvents lblTexto As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Panel25 As Panel
    Friend WithEvents Panel32 As Panel
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Panel33 As Panel
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Panel34 As Panel
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Panel35 As Panel
    Friend WithEvents Panel27 As Panel
    Friend WithEvents Panel36 As Panel
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Panel28 As Panel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Panel29 As Panel
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Panel30 As Panel
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Panel24 As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Panel12 As Panel
    Friend WithEvents btnGenerar As Button
    Friend WithEvents rbForeground As RadioButton
    Friend WithEvents rbBackground As RadioButton
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel1 As Panel
End Class
